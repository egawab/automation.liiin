/**
 * Nexora Network Interceptor v5.0 — Content-Based Feed Detection
 * ─────────────────────────────────────────────────────────────────────────────
 * v5.0 vs v4.0:
 *  ROOT CAUSE FIX: v4.0 filtered by URL patterns (queryIds, endpoint names) that
 *  LinkedIn constantly rotates across A/B variants. Only ~5 posts were captured
 *  because the real data responses were on non-matching URLs.
 *
 *  v5.0 STRATEGY — Content-Based Detection:
 *    1. Allow ALL non-static LinkedIn API responses through (broad URL gate).
 *    2. Inspect every response BODY for real post content signals:
 *       - "urn:li:activity", "urn:li:ugcPost", "urn:li:share" in body
 *       - "included" array with objects (Voyager envelope)
 *       - engagement keys (numLikes, totalReactionCount, numComments…)
 *       - feed/search entity markers (entityResult, feedUpdate, etc.)
 *    3. Only run the expensive parser on bodies that pass the content check.
 *    4. Suppress known signal-only endpoints (impressions, analytics, logging).
 *
 *  Result: Works across Search A, Search B, any GraphQL A/B variant — without
 *  relying on any specific endpoint name or queryId.
 * ─────────────────────────────────────────────────────────────────────────────
 */
(function () {
  'use strict';

  if (window.__NEXORA_INTERCEPTOR_V5__) return;
  window.__NEXORA_INTERCEPTOR_V5__ = true;

  // ── BROAD URL gate: catch every LinkedIn API call ─────────────────────────
  // We allow anything that looks like a LinkedIn API/data endpoint.
  // Static assets, auth pages, and known noise are excluded.
  const EXCLUDE_URL_FRAGMENTS = [
    '/static/', '.js', '.css', '.png', '.jpg', '.jpeg', '.gif', '.svg',
    '.woff', '.woff2', '.ttf', '.ico', '.webp', '.mp4', '.webm',
    '/login', '/authwall', '/uas/', '/checkpoint/',
    'li/track', 'li/pixels', 'li/collect', 'analytics.licdn',
    'px.ads.linkedin', 'snap.licdn', 'platform.linkedin',
    '/favicon', '/robots.txt', '/sitemap',
  ];

  // Known pure-signal endpoints that NEVER carry post content
  const SIGNAL_URL_FRAGMENTS = [
    'feedDashClientSignal', 'clientSignal', 'impression',
    '/tracking', '/realtime/', '/push/', '/notifications/seen',
    'loggingEndpoint', 'li/loggingEndpoints',
    '/update/', '/seen/', '/click-tracking',
    'performanceMetrics', 'analyticsTracking',
  ];

  function isLinkedInApiUrl(url) {
    if (!url) return false;
    const u = String(url);
    // Must be LinkedIn or a relative path
    if (!u.includes('linkedin.com') && !u.startsWith('/')) return false;
    // Drop static assets
    for (const f of EXCLUDE_URL_FRAGMENTS) {
      if (u.includes(f) || u.endsWith(f)) return false;
    }
    // Drop pure signal/analytics endpoints
    for (const f of SIGNAL_URL_FRAGMENTS) {
      if (u.includes(f)) return false;
    }
    return true;
  }

  // ── CONTENT-BASED gate: does this body contain real post data? ───────────
  // Minimum viable signals — at least ONE must be present.
  const CONTENT_SIGNALS = [
    'urn:li:activity:',
    'urn:li:ugcPost:',
    'urn:li:share:',
    '"entityResult"',
    '"feedUpdate"',
    '"feedUpdates"',
    '"updateMetadata"',
    '"socialDetail"',
    '"socialActivityCountsInsight"',
    '"totalReactionCount"',
    '"numLikes"',
    '"likeCount"',
    '"numComments"',
    '"commentCount"',
    '"commentary"',       // Voyager post text field
    '"ugcPost"',
    '"resharedUpdate"',
    '"fsd_update"',
    '"fsd_socialActivityCounts"',
  ];

  function bodyHasFeedContent(body) {
    if (!body || body.length < 80) return false;
    // Quick scan — check for at least one signal (fast path)
    for (const sig of CONTENT_SIGNALS) {
      if (body.includes(sig)) return true;
    }
    return false;
  }

  // ── URN patterns ───────────────────────────────────────────────────────────
  const URN_RE        = /urn:li:(activity|ugcPost|share):(\d{10,25})/i;
  const URN_RE_GLOBAL = /urn:li:(activity|ugcPost|share):(\d{10,25})/gi;

  function buildUrl(type, id) {
    const t = (type || '').toLowerCase();
    if (t === 'ugcpost') return `https://www.linkedin.com/feed/update/urn:li:ugcPost:${id}`;
    if (t === 'share')   return `https://www.linkedin.com/feed/update/urn:li:share:${id}`;
    return `https://www.linkedin.com/feed/update/urn:li:activity:${id}`;
  }

  function parseCount(v) {
    if (v == null) return null;
    if (typeof v === 'number') return isNaN(v) ? null : Math.floor(v);
    const s = String(v).replace(/,/g, '').trim().toUpperCase();
    if (!s) return null;
    if (s.endsWith('K')) { const n = Math.round(parseFloat(s) * 1000); return isNaN(n) ? null : n; }
    if (s.endsWith('M')) { const n = Math.round(parseFloat(s) * 1e6);  return isNaN(n) ? null : n; }
    const n = Math.floor(parseFloat(s));
    return isNaN(n) ? null : n;
  }

  function nullMax(a, b) {
    if (a == null && b == null) return null;
    if (a == null) return b;
    if (b == null) return a;
    return Math.max(a, b);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PASS 1: JSON tree walk — per-entity extraction
  // ══════════════════════════════════════════════════════════════════════════
  const LIKE_KEYS    = ['numLikes','totalReactionCount','likeCount','reactionCount',
                        'aggregatedReactionCount','totalLikeCount','totalReactions',
                        'numReactions','aggregatedTotalReactions'];
  const COMMENT_KEYS = ['numComments','commentCount','totalCommentCount',
                        'commentsCount','totalSocialCommentCount'];
  const SHARE_KEYS   = ['numShares','repostCount','shareCount','sharesCount'];
  const TEXT_OBJ_KEYS = ['commentary','summary','description','primarySubtitle',
                          'heroInfo','insightText','content'];

  function walkJsonTree(obj, depth) {
    if (!obj || typeof obj !== 'object' || depth > 20) return [];
    const results = [];
    const rawUrn = obj.entityUrn || obj.updateUrn || obj.objectUrn || obj.urn || '';
    const urnMatch = String(rawUrn).match(URN_RE);
    if (urnMatch) {
      const post = extractNodePost(obj, urnMatch[1], urnMatch[2]);
      if (post) results.push(post);
    }
    const children = Array.isArray(obj) ? obj : Object.values(obj);
    for (const child of children) {
      if (child && typeof child === 'object') {
        const sub = walkJsonTree(child, depth + 1);
        if (sub.length) results.push(...sub);
      }
    }
    return results;
  }

  function extractNodePost(node, urnType, urnId) {
    const url = buildUrl(urnType, urnId);
    let likes = null, comments = null, reposts = null;
    let text = '', author = '';

    function scanNode(obj, d) {
      if (!obj || typeof obj !== 'object' || d > 12) return;

      for (const k of LIKE_KEYS) {
        if (typeof obj[k] === 'number') likes = nullMax(likes, parseCount(obj[k]));
      }
      for (const k of COMMENT_KEYS) {
        if (typeof obj[k] === 'number') comments = nullMax(comments, parseCount(obj[k]));
      }
      for (const k of SHARE_KEYS) {
        if (typeof obj[k] === 'number') reposts = nullMax(reposts, parseCount(obj[k]));
      }

      for (const k of TEXT_OBJ_KEYS) {
        const sub = obj[k];
        if (sub && typeof sub.text === 'string' && sub.text.length > text.length) {
          text = sub.text;
        }
      }
      if (typeof obj.text === 'string' && obj.text.length > 20 && obj.text.length > text.length
          && obj.text.length < 8000) {
        text = obj.text;
      }

      if (likes == null && typeof obj.socialProofText === 'string') {
        const m = obj.socialProofText.match(/([\d,]+)\s*reactions?/i);
        if (m) likes = parseCount(m[1].replace(/,/g, ''));
      }
      if (obj.socialActivityCountsInsight) {
        const s = obj.socialActivityCountsInsight;
        if (typeof s.numLikes === 'number')    likes    = nullMax(likes, s.numLikes);
        if (typeof s.numComments === 'number') comments = nullMax(comments, s.numComments);
      }

      if (!author) {
        const nameFields = ['actorName', 'firstName', 'fullName', 'localizedName'];
        for (const k of nameFields) {
          if (typeof obj[k] === 'string') {
            const a = obj[k].trim();
            if (a.length >= 2 && a.length <= 80 && !/^\d/.test(a) && !a.includes('http')) {
              author = a; break;
            }
          }
        }
      }
      if (!author && obj.actor) {
        const n = obj.actor.name;
        const t = (n && typeof n === 'object') ? (n.text || '') : (typeof n === 'string' ? n : '');
        if (t.length >= 2) author = t;
      }
      if (!author && obj.title && typeof obj.title.text === 'string') {
        const a = obj.title.text.trim();
        if (a.length >= 2 && a.length <= 80 && !/^\d/.test(a) && !a.includes('http')) author = a;
      }
      if (!author && obj.name && typeof obj.name.text === 'string') {
        const a = obj.name.text.trim();
        if (a.length >= 2 && a.length <= 80 && !/^\d/.test(a) && !a.includes('http')) author = a;
      }

      const kids = Array.isArray(obj) ? obj : Object.values(obj);
      for (const kid of kids) {
        if (kid && typeof kid === 'object') scanNode(kid, d + 1);
      }
    }

    scanNode(node, 0);
    return { url, likes, comments, reposts, text: text.slice(0, 5000), author, source: 'network_json' };
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PASS 3: Proximity scan — ±2000 chars around each URN
  // ══════════════════════════════════════════════════════════════════════════
  function proximityExtract(body) {
    const results = [];
    const seenUrls = new Set();
    URN_RE_GLOBAL.lastIndex = 0;
    let m;
    while ((m = URN_RE_GLOBAL.exec(body)) !== null) {
      const url = buildUrl(m[1], m[2]);
      if (seenUrls.has(url)) continue;
      seenUrls.add(url);
      const lo  = Math.max(0, m.index - 2000);
      const hi  = Math.min(body.length, m.index + 2000);
      const win = body.slice(lo, hi);
      results.push(extractFromWindow(win, url));
    }
    return results;
  }

  function extractFromWindow(win, url) {
    let likes = null, comments = null, reposts = null, text = '', author = '';

    for (const k of LIKE_KEYS) {
      const re = new RegExp(`"${k}"\\s*:\\s*(\\d+)`, 'g');
      let mm;
      while ((mm = re.exec(win)) !== null) likes = nullMax(likes, parseInt(mm[1], 10));
    }
    for (const k of COMMENT_KEYS) {
      const re = new RegExp(`"${k}"\\s*:\\s*(\\d+)`, 'g');
      let mm;
      while ((mm = re.exec(win)) !== null) comments = nullMax(comments, parseInt(mm[1], 10));
    }
    for (const k of SHARE_KEYS) {
      const re = new RegExp(`"${k}"\\s*:\\s*(\\d+)`, 'g');
      let mm;
      while ((mm = re.exec(win)) !== null) reposts = nullMax(reposts, parseInt(mm[1], 10));
    }

    if (likes == null) {
      const re = /"socialProofText"\s*:\s*"([^"]*)"/g;
      let mm;
      while ((mm = re.exec(win)) !== null) {
        const cnt = mm[1].match(/([\d,]+)\s*reactions?/i);
        if (cnt) likes = nullMax(likes, parseCount(cnt[1].replace(/,/g, '')));
      }
    }

    {
      const re = /"socialActivityCountsInsight"\s*:\s*\{([^}]{0,400})\}/g;
      let mm;
      while ((mm = re.exec(win)) !== null) {
        const inner = mm[1];
        const lm = inner.match(/"numLikes"\s*:\s*(\d+)/);
        const cm = inner.match(/"numComments"\s*:\s*(\d+)/);
        if (lm) likes    = nullMax(likes, parseInt(lm[1], 10));
        if (cm) comments = nullMax(comments, parseInt(cm[1], 10));
      }
    }

    if (likes == null) {
      const re = /([\d,]+)\s+reactions?\b/gi;
      let mm;
      while ((mm = re.exec(win)) !== null) likes = nullMax(likes, parseCount(mm[1].replace(/,/g, '')));
    }

    for (const k of TEXT_OBJ_KEYS) {
      const re = new RegExp(`"${k}"\\s*:\\s*\\{[^{}]*?"text"\\s*:\\s*"((?:[^"\\\\]|\\\\.){20,})"`, 'g');
      let mm;
      while ((mm = re.exec(win)) !== null) {
        const t = mm[1].replace(/\\n/g, ' ').replace(/\\"/g, '"');
        if (t.length > text.length && t.length < 8000) text = t;
      }
    }
    if (text.length < 20) {
      const re = /"text"\s*:\s*"((?:[^"\\]|\\.){20,})"/g;
      let mm;
      while ((mm = re.exec(win)) !== null) {
        const t = mm[1].replace(/\\n/g, ' ').replace(/\\"/g, '"');
        if (t.length > text.length && t.length < 8000) text = t;
      }
    }

    const authorPatterns = [
      /"actorName"\s*:\s*"([^"]{2,80})"/,
      /"title"\s*:\s*\{[^{}]*?"text"\s*:\s*"([^"]{2,80})"/,
      /"name"\s*:\s*\{[^{}]*?"text"\s*:\s*"([^"]{2,80})"/,
      /"fullName"\s*:\s*"([^"]{2,80})"/,
      /"localizedName"\s*:\s*"([^"]{2,80})"/,
    ];
    for (const re of authorPatterns) {
      const mm = re.exec(win);
      if (mm) {
        const a = mm[1].trim();
        if (a.length >= 2 && a.length <= 80 && !/^\d/.test(a) && !a.includes('http')) {
          author = a; break;
        }
      }
    }

    return { url, likes, comments, reposts, text: text.slice(0, 5000), author, source: 'network_proximity' };
  }

  // ══════════════════════════════════════════════════════════════════════════
  // Merge helpers — deduplicate and take best fields
  // ══════════════════════════════════════════════════════════════════════════
  function mergePostList(posts) {
    const map = new Map();
    for (const p of posts) {
      if (!p || !p.url) continue;
      const ex = map.get(p.url);
      if (!ex) {
        map.set(p.url, Object.assign({}, p));
      } else {
        if ((p.text || '').length > (ex.text || '').length) ex.text = p.text;
        if (!ex.author && p.author) ex.author = p.author;
        ex.likes    = nullMax(ex.likes,    p.likes);
        ex.comments = nullMax(ex.comments, p.comments);
        ex.reposts  = nullMax(ex.reposts,  p.reposts);
        if (!ex.source.includes(p.source)) ex.source += '+' + p.source;
      }
    }
    return Array.from(map.values());
  }

  // ══════════════════════════════════════════════════════════════════════════
  // Main entry: process a response body
  // ══════════════════════════════════════════════════════════════════════════
  function processBody(body, sourceUrl) {
    if (!body || body.length < 50) return;

    // ── Content gate: only parse bodies that actually contain post signals ─
    if (!bodyHasFeedContent(body)) return;

    let posts = [];
    let passUsed = '';

    // Pass 1: Try full JSON parse
    try {
      const parsed = JSON.parse(body);
      const found  = walkJsonTree(parsed, 0);
      if (found.length > 0) { posts = found; passUsed = 'json'; }
    } catch (_) {}

    // Pass 2: NDJSON (line-delimited)
    if (posts.length === 0 && body.includes('\n')) {
      const lineResults = [];
      for (const line of body.split('\n')) {
        if (line.length < 20) continue;
        try {
          const obj   = JSON.parse(line);
          const found = walkJsonTree(obj, 0);
          lineResults.push(...found);
        } catch (_) {}
      }
      if (lineResults.length > 0) { posts = lineResults; passUsed = 'ndjson'; }
    }

    // Pass 3: Proximity regex scan (RSC raw chunks)
    if (posts.length === 0) {
      posts    = proximityExtract(body);
      passUsed = 'proximity';
    }

    if (posts.length === 0) return;

    const merged = mergePostList(posts);

    const srcLabel = (sourceUrl || '').split('?')[0].slice(-60);
    console.log(`[Nexora][Interceptor v5.0] ${passUsed}: ${merged.length} posts from ${srcLabel}`);
    for (const p of merged) {
      console.log(
        `[Nexora][Interceptor v5.0]   urn=${p.url.split('/').pop()} ` +
        `likes=${p.likes ?? 'null'} comments=${p.comments ?? 'null'} ` +
        `author="${p.author || ''}" textLen=${(p.text || '').length}`
      );
    }

    window.__NexoraEmbeddedPosts = window.__NexoraEmbeddedPosts || [];
    window.__NexoraEmbeddedPosts.push(...merged);
    window.postMessage({ type: '__NEXORA_NETWORK_POSTS__', posts: merged, sourceUrl }, '*');
  }

  // ── Scan <code> elements (SEARCH_B pre-load) ──────────────────────────────
  const _scannedCodes = new WeakSet();

  function scanEmbeddedData() {
    let found = 0;
    document.querySelectorAll('code').forEach(el => {
      if (_scannedCodes.has(el)) return;
      _scannedCodes.add(el);
      try {
        const t = el.textContent || '';
        if (t.length > 80 && bodyHasFeedContent(t)) {
          processBody(t, 'bpr:' + (el.id || 'inline'));
          found++;
        }
      } catch (_) {}
    });
    if (found > 0) console.log(`[Nexora][Interceptor v5.0] Scanned ${found} <code> elements`);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(scanEmbeddedData, 200));
  } else {
    setTimeout(scanEmbeddedData, 200);
  }

  const _codeObserver = new MutationObserver(() => scanEmbeddedData());
  if (document.body) {
    _codeObserver.observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      _codeObserver.observe(document.body || document.documentElement, { childList: true, subtree: true });
    });
  }

  // ── Patch fetch ────────────────────────────────────────────────────────────
  const _origFetch = window.fetch.bind(window);
  window.fetch = function (...args) {
    const url  = typeof args[0] === 'string' ? args[0] : ((args[0] || {}).url || '');
    const prom = _origFetch(...args);
    if (isLinkedInApiUrl(url)) {
      prom.then(resp => {
        try {
          resp.clone().text().then(b => {
            if (b && b.length > 50) processBody(b, url);
          }).catch(() => {});
        } catch (_) {}
      }).catch(() => {});
    }
    return prom;
  };

  // ── Patch XHR ──────────────────────────────────────────────────────────────
  const _origOpen = XMLHttpRequest.prototype.open;
  const _origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._nexoraUrl = String(url || '');
    return _origOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    if (this._nexoraUrl && isLinkedInApiUrl(this._nexoraUrl)) {
      this.addEventListener('load', () => {
        try {
          let body = '';
          if (this.responseType === 'json') {
            body = JSON.stringify(this.response);
          } else if (this.responseType === 'arraybuffer' || this.responseType === 'blob') {
            return;
          } else {
            body = this.responseText;
          }
          if (body && body.length > 50) processBody(body, this._nexoraUrl);
        } catch (e) {
          console.log('[Nexora][Interceptor] XHR read error', e.message);
        }
      }, { once: true });
    }
    return _origSend.apply(this, args);
  };

  console.log('[Nexora][Interceptor v5.0] Content-based feed detection active on', location.href.slice(0, 80));
})();
