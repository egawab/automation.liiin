/**
 * Nexora Core Engine v5.0 — Pure DOM Scraper
 * ─────────────────────────────────────────────────────────────────────────────
 * v5.0 Architecture: Pure DOM Extraction
 *
 * PHASE 1 — COLLECTION (scroll steps 1–60):
 *   Maintain a central _enrichmentStore: Map<uniqueKey, PostRecord>.
 *   On each harvest:
 *     1. Discover DOM cards -> extract visible DOM data.
 *     2. Add to store if new (using URL or text/author fingerprint).
 *   NOTHING is sent to Transport during this phase.
 *
 * PHASE 2 — FLUSH (after observer calls onExhausted):
 *   1. Iterate _enrichmentStore.
 *   2. Send directly to Transport.
 *   3. NO network interception, NO GraphQL parsing, NO hydration.
 * ─────────────────────────────────────────────────────────────────────────────
 */
(function () {
  'use strict';

  if (window.__NexoraEngine) return;

  const CFG  = () => window.__NexoraConfig         || {};
  const L    = () => window.__NexoraLogger         || { info(){}, warn(){}, error(){}, debug(){}, setDebug(){} };
  const DA   = () => window.__NexoraDomAdapter     || { discoverCards(){ return []; }, extractCanonicalUrl(){ return null; }, getFeedContainer(){ return document.body; } };
  const EX   = () => window.__NexoraExtractor      || { extractFromCard(){ return {}; } };
  const TR   = () => window.__NexoraTransport      || { buffer(){}, flush(){}, configure(){}, reset(){}, getSentCount(){ return 0; } };
  const OBS  = () => window.__NexoraObserver       || { start(){}, stop(){}, onHarvestComplete(){} };

  const MODULE = 'Engine';

  // ── State ────────────────────────────────────────────────────────────────
  let _running        = false;
  let _keyword        = '';
  let _dashboardUrl   = '';
  let _userId         = '';
  let _profileId      = 'Unknown';
  let _heartbeatTimer = null;

  // Phase 1 state
  let _seenCardEls    = new WeakSet(); // DOM elements already processed
  let _enrichmentStore= new Map();     // uniqueKey → PostRecord (central truth)

  // ── Helpers ──────────────────────────────────────────────────────────────
  function safeSend(msg) {
    try {
      chrome.runtime.sendMessage(msg, () => {
        if (chrome.runtime.lastError) { /* ignore */ }
      });
    } catch (e) {}
  }

  function heartbeat(phase) { safeSend({ action: 'HEARTBEAT', phase }); }

  function status(text) {
    L().info(MODULE, text);
    safeSend({ action: 'LIVE_STATUS', text });
  }

  function startHeartbeat() {
    stopHeartbeat();
    _heartbeatTimer = setInterval(() => heartbeat('search_only'), 20000);
  }

  function stopHeartbeat() {
    if (_heartbeatTimer) { clearInterval(_heartbeatTimer); _heartbeatTimer = null; }
  }

  // ── URL/Key normalization ─────────────────────────────────────────────────────
  function normalizePostUrl(url) {
    if (!url) return '';
    const m1 = url.match(/urn:li:(activity|ugcPost|share):(\d{10,25})/);
    if (m1) return `https://www.linkedin.com/feed/update/urn:li:${m1[1]}:${m1[2]}`;
    const m2 = url.match(/ugcPost-(\d{10,25})/i);
    if (m2) return `https://www.linkedin.com/feed/update/urn:li:ugcPost:${m2[1]}`;
    const m3 = url.match(/activity-(\d{10,25})/i);
    if (m3) return `https://www.linkedin.com/feed/update/urn:li:activity:${m3[1]}`;
    return url.split('?')[0].replace(/\/$/, '');
  }

  function generateFingerprint(post) {
    if (post.url) return normalizePostUrl(post.url);
    const authorSnippet = (post.author || '').toLowerCase().replace(/\s+/g, '').substring(0, 20);
    const textSnippet = (post.text || '').toLowerCase().replace(/\s+/g, '').substring(0, 50);
    if (!authorSnippet && !textSnippet) return `unknown-${Math.random()}`;
    return `fp_${authorSnippet}_${textSnippet}`;
  }

  // ── Enrichment store operations ───────────────────────────────────────────
  function mergeIntoStore(uniqueKey, incoming) {
    if (!uniqueKey) return;

    const existing = _enrichmentStore.get(uniqueKey);
    if (!existing) {
      _enrichmentStore.set(uniqueKey, { ...incoming });
      return;
    }

    // Update with best DOM data if available
    const inText = incoming.text || '';
    const exText = existing.text || '';
    if (inText.length > exText.length) existing.text = inText;

    const inAuth = incoming.author || '';
    const exAuth = existing.author || '';
    if (!exAuth && inAuth) existing.author = inAuth;

    if (existing.likes == null && incoming.likes != null) existing.likes = incoming.likes;
    if (existing.comments == null && incoming.comments != null) existing.comments = incoming.comments;
  }

  // ── PHASE 1: Per-scroll harvest ───────────────────────────────────────────
  function harvest() {
    if (!_running) return;

    heartbeat('harvesting');

    const layout = 'SEARCH_B'; // Search results layout
    const cards  = DA().discoverCards(layout);
    let newCardsFound = 0;

    for (const card of cards) {
      if (_seenCardEls.has(card)) continue;
      _seenCardEls.add(card);

      let post;
      try {
        post = EX().extractFromCard(card, { layoutId: layout });
      } catch (e) {
        L().warn(MODULE, 'extractFromCard threw', e.message);
        continue;
      }

      const uniqueKey = generateFingerprint(post);
      if (!_enrichmentStore.has(uniqueKey)) {
        newCardsFound++;
      }
      mergeIntoStore(uniqueKey, post);
    }

    const storeSize = _enrichmentStore.size;
    status(`🔍 "${_keyword}" — Step ${OBS().getStep()} | Store: ${storeSize} posts | New: ${newCardsFound}`);
    OBS().onHarvestComplete(newCardsFound);
  }

  // ── Profile ID detection ─────────────────────────────────────────────────
  function detectProfileId() {
    try {
      const meLink = document.querySelector(
        'a[href*="/in/"][aria-label*="me" i], a[data-test-app-aware-link][href*="/in/"]'
      );
      if (meLink) {
        const href = meLink.getAttribute('href') || '';
        const m    = href.match(/\/in\/([^/?#]+)/i);
        if (m) {
          _profileId = m[1];
          safeSend({ action: 'IDENTITY_DETECTED', linkedInProfileId: _profileId });
        }
      }
    } catch (e) {}
  }

  // ── PHASE 2: Final flush ─────────────────────────────────────────────────
  async function flushAllPosts() {
    L().info(MODULE, `Phase 2: Flushing ${_enrichmentStore.size} posts from enrichment store…`);

    let sentCount   = 0;

    for (const [key, record] of _enrichmentStore) {
      // Real-time filtering: MUST have >= 10 likes
      if (record.likes == null || record.likes < 10) {
        L().debug(MODULE, `[Filter] Dropped post (likes < 10 or null): ${record.likes} likes`);
        continue;
      }

      const finalPost = {
        text:      record.text || '',
        author:    record.author || '',
        url:       record.url || '',
        likes:     record.likes,
        comments:  record.comments || 0,
        source:    'linkedin'
      };

      TR().buffer(finalPost);
      sentCount++;

      if (sentCount >= (CFG().MAX_POSTS_PER_RUN || 500)) {
        L().info(MODULE, `Hit MAX_POSTS_PER_RUN cap (${CFG().MAX_POSTS_PER_RUN || 500})`);
        break;
      }
    }

    L().info(MODULE, `Phase 2: Buffered ${sentCount} posts`);
    try { await TR().flush(); } catch (e) { L().warn(MODULE, 'flush error', e.message); }
    return sentCount;
  }

  // ── Completion ───────────────────────────────────────────────────────────
  async function onExhausted(reason) {
    L().info(MODULE, `Observer exhausted: ${reason}. Entering Phase 2.`);
    await finish(reason);
  }

  async function finish(reason) {
    if (!_running) return;
    _running = false;

    stopHeartbeat();
    OBS().stop();

    status(`⏳ "${_keyword}" — Collecting final data…`);

    const sentCount = await flushAllPosts();

    L().info(MODULE, `Run complete. reason=${reason} store=${_enrichmentStore.size} sent=${sentCount}`);
    status(`✅ "${_keyword}" done — ${sentCount} posts stored`);

    if (sentCount === 0 && _enrichmentStore.size === 0) {
      safeSend({
        action:            'JOB_FAILED',
        searchOnlyMode:    true,
        postsExtracted:    0,
        qualifiedPosts:    0,
        keyword:           _keyword,
        linkedInProfileId: _profileId,
        reason:            'NO_CONTENT',
      });
      return;
    }

    safeSend({
      action:            'JOB_COMPLETED',
      searchOnlyMode:    true,
      postsExtracted:    _enrichmentStore.size,
      qualifiedPosts:    sentCount,
      keyword:           _keyword,
      linkedInProfileId: _profileId,
      reason,
    });
  }

  async function emergencySync() {
    L().info(MODULE, 'Emergency sync triggered');
    try { await TR().flush(); } catch (e) {}
  }

  // ── Start ─────────────────────────────────────────────────────────────────
  async function start(keyword, settings, dashboardUrl, userId) {
    if (_running) {
      L().warn(MODULE, 'Already running — ignoring duplicate start');
      return;
    }

    _running         = true;
    _keyword         = keyword      || '';
    _dashboardUrl    = dashboardUrl || '';
    _userId          = userId       || '';
    _seenCardEls     = new WeakSet();
    _enrichmentStore = new Map();

    const forcedOverrides = {
      MAX_SCROLL_STEPS:      60,
      STALL_THRESHOLD:       999,
      LIKE_THRESHOLD:        0,
      INCLUDE_UNKNOWN_LIKES: true,
      MAX_POSTS_PER_RUN:     500,
    };

    if (settings && CFG().update) {
      const userOverrides = {};
      if (settings.maxPosts != null) userOverrides.MAX_POSTS_PER_RUN = Number(settings.maxPosts);
      CFG().update(userOverrides);
    }
    CFG().update && CFG().update(forcedOverrides);
    if (CFG().load) await CFG().load();
    CFG().update && CFG().update(forcedOverrides);

    L().info(MODULE, `Engine v5.0 (Pure DOM) starting: keyword="${_keyword}"`);
    status(`🚀 Starting DOM extraction for "${_keyword}"…`);

    TR().configure({
      keyword:           _keyword,
      dashboardUrl:      _dashboardUrl,
      userId:            _userId,
      linkedInProfileId: _profileId,
    });
    TR().reset();

    detectProfileId();

    await new Promise(r => setTimeout(r, 1200));

    startHeartbeat();
    OBS().start(harvest, onExhausted);
  }

  function stop() {
    if (!_running) return;
    _running = false;
    stopHeartbeat();
    OBS().stop();
    TR().flush().catch(() => {});
  }

  window.__NexoraEngine = { start, stop, emergencySync };

  window.__linkedInExtractorCleanup = window.__linkedInExtractorCleanup || function () {};
  const _prevCleanup = window.__linkedInExtractorCleanup;
  window.__linkedInExtractorCleanup = function () {
    try { _prevCleanup(); } catch (e) {}
    stop();
  };

  window.__emergencySync = emergencySync;

  console.log('[Nexora][Engine v5.0] Pure DOM engine ready.');
})();
